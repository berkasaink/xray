#!/bin/bash
# TODO: Implementasi install-squid.sh
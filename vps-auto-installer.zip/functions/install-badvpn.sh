#!/bin/bash
# TODO: Implementasi install-badvpn.sh
#!/bin/bash
# TODO: Implementasi monitor-bandwidth.sh
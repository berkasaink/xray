#!/bin/bash
echo "=============================="
echo " VPS MANAGEMENT MENU"
echo "=============================="
echo "1. Tambah Akun"
echo "2. Perpanjang Akun"
echo "3. Hapus Akun"
echo "4. Lihat Akun Aktif"
echo "5. Lihat Akun Akan Expired"
echo "6. Backup & Restore"
echo "7. Monitoring Bandwidth"
echo "8. Reboot Otomatis"
echo "0. Keluar"
read -p "Pilih opsi: " opt

case $opt in
  1) bash functions/add-user.sh ;;
  2) bash functions/renew-user.sh ;;
  3) bash functions/delete-user.sh ;;
  4) bash functions/list-user.sh ;;
  5) bash functions/expired-user.sh ;;
  6) bash functions/backup-restore.sh ;;
  7) bash functions/monitor-bandwidth.sh ;;
  8) reboot ;;
  0) exit ;;
  *) echo "Opsi tidak valid!" ;;
esac

#!/bin/bash
clear
echo "============================"
echo " VPS AUTO INSTALLER v1.0"
echo "============================"
read -p "Masukkan domain yang akan digunakan: " domain

# Simpan domain ke file
echo "$domain" > /etc/xray/domain

# Update & install acme.sh
apt update -y && apt upgrade -y
apt install curl socat -y
curl https://acme.sh | sh
~/.acme.sh/acme.sh --register-account -m admin@$domain --server letsencrypt
~/.acme.sh/acme.sh --issue -d $domain --standalone -k ec-256
~/.acme.sh/acme.sh --install-cert -d $domain --ecc \
  --fullchain-file /etc/ssl/$domain.crt \
  --key-file /etc/ssl/$domain.key

# Simpan path cert
mkdir -p /etc/ssl
echo "/etc/ssl/$domain.crt" > /etc/ssl/cert.crtpath
echo "/etc/ssl/$domain.key" > /etc/ssl/cert.keypath

# Install komponen
bash functions/install-sshws.sh
bash functions/install-xray.sh
bash functions/install-stunnel5.sh
bash functions/install-squid.sh
bash functions/install-badvpn.sh
bash functions/install-openvpn.sh
bash functions/cronjobs.sh

# Pasang menu
cp menu.sh /usr/local/bin/menu
chmod +x /usr/local/bin/menu

clear
echo "INSTALLASI SELESAI!"
echo "Jalankan perintah: menu"

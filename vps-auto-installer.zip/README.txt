# AUTO INSTALLER VPS UBUNTU 24.04

## Jalankan installer:
```bash
chmod +x auto-install.sh
./auto-install.sh
```

Setelah install, gunakan:
```bash
menu
```

Semua fitur SSH WS, Xray (VMess & Trojan-Go), Stunnel5, Squid, OpenVPN, BadVPN, backup, bandwidth monitoring dan auto-kill sudah tersedia.

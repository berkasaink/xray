#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
XRAY_SERVICE="xray"

# Ambil semua user trojan
user_list=($(jq -r '.inbounds[] | select(.protocol=="trojan") | .settings.clients[].email' "$CONFIG_FILE"))

# Cek jika kosong
if [ ${#user_list[@]} -eq 0 ]; then
  echo "❌ Tidak ada user Trojan yang tersedia."
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

# Tampilkan daftar
echo "🔐 Daftar User Trojan:"
echo "────────────────────────────"
for i in "${!user_list[@]}"; do
  echo "$((i+1)). ${user_list[$i]}"
done
echo "────────────────────────────"

# Pilih user
read -p "🔢 Pilih nomor user yang akan diubah passwordnya: " pilih
index=$((pilih-1))
user="${user_list[$index]}"

# Minta password baru
read -p "🆕 Masukkan password baru untuk '$user': " new_pass

# Ubah password
tmpfile=$(mktemp)
jq --arg user "$user" --arg pass "$new_pass" '
  (.inbounds[] 
   | select(.protocol == "trojan") 
   | .settings.clients[] 
   | select(.email == $user)).password = $pass' \
  "$CONFIG_FILE" > "$tmpfile" && mv "$tmpfile" "$CONFIG_FILE"

# Restart service
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart "$XRAY_SERVICE"

echo ""
echo "✅ Password user '$user' berhasil diubah!"
echo "🔑 Password baru: $new_pass"
read -n1 -s -r -p "Tekan tombol untuk kembali ke menu..."


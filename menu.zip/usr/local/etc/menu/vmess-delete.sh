#!/bin/bash

config_file="/usr/local/etc/xray/config.json"

clear
echo "=== Hapus Akun VMess ==="

# Ambil list user dari config.json
users=$(jq -r '.inbounds[] | select(.tag=="vmess") | .settings.clients[]?.email' "$config_file")
if [[ -z "$users" ]]; then
  echo "❌ Tidak ada akun VMess yang ditemukan."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit
fi

# Tampilkan daftar user
i=1
declare -A usermap
echo "=== Daftar Akun VMess ==="
while read -r user; do
  echo " $i) $user"
  usermap[$i]="$user"
  ((i++))
done <<< "$users"

# Input pilihan user
echo -n "Pilih nomor user untuk dihapus: "; read pilihan
username="${usermap[$pilihan]}"

# Validasi input
if [[ -z "$username" ]]; then
  echo "❌ Pilihan tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit
fi

# Hapus user
tmp=$(mktemp)
jq '(.inbounds[] | select(.tag == "vmess") | .settings.clients) |= map(select(.email != "'$username'"))' \
  "$config_file" > "$tmp" && mv "$tmp" "$config_file"

# Restart Xray
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart xray

echo "✅ Akun '$username' berhasil dihapus."
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


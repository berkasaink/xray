#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
DOMAIN=$(cat /etc/xray/domain 2>/dev/null || echo "example.com")
PORT_WS=80
PORT_WSS=443

clear
echo "=== Perpanjang Akun VMess ==="

# Ambil daftar user dari config.json
users=($(jq -r '.inbounds[] | select(.protocol=="vmess") | .settings.clients[]?.email' "$CONFIG_FILE"))

if [ ${#users[@]} -eq 0 ]; then
  echo "Tidak ada user yang ditemukan."
    read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 0
fi

echo "=== Daftar User VMess yang Akan Diperpanjang ==="
for i in "${!users[@]}"; do
  user="${users[$i]}"
  exp=$(jq -r ".inbounds[] | select(.protocol==\"vmess\") | .settings.clients[] | select(.email==\"$user\") | .expireDate" "$CONFIG_FILE")
  [[ "$exp" == "null" || -z "$exp" ]] && exp="Tidak ada tanggal expired"
  printf " %2d) %-20s Exp: %s\n" "$((i+1))" "$user" "$exp"
done

echo -ne "\nPilih nomor user untuk diperpanjang: "; read pilihan

if ! [[ "$pilihan" =~ ^[0-9]+$ ]] || (( pilihan < 1 || pilihan > ${#users[@]} )); then
  echo "Pilihan tidak valid."
  exit 1
fi

selected_user="${users[$((pilihan-1))]}"
echo -n "Masukkan jumlah hari perpanjangan: "; read hari
if ! [[ "$hari" =~ ^[0-9]+$ ]]; then
  echo "Input hari tidak valid."
  exit 1
fi

# Hitung tanggal expired baru
exp_now=$(jq -r ".inbounds[] | select(.protocol==\"vmess\") | .settings.clients[] | select(.email==\"$selected_user\") | .expireDate" "$CONFIG_FILE")
if [[ "$exp_now" == "null" || -z "$exp_now" ]]; then
  new_exp=$(date -d "+$hari days" +"%Y-%m-%d")
else
  new_exp=$(date -d "$exp_now +$hari days" +"%Y-%m-%d")
fi

# Perbarui expireDate
TMP_FILE=$(mktemp)
jq --arg user "$selected_user" --arg new_exp "$new_exp" '(.inbounds[] | select(.protocol=="vmess") | .settings.clients[] | select(.email==$user) | .expireDate) = $new_exp' "$CONFIG_FILE" > "$TMP_FILE" && mv "$TMP_FILE" "$CONFIG_FILE"

chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart xray > /dev/null 2>&1

echo "\nAkun VMess dengan username $selected_user berhasil diperpanjang hingga $new_exp."
    read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."

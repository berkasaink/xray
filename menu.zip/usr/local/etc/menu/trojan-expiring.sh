#!/bin/bash

CONFIG="/usr/local/etc/xray/config.json"
today=$(date +%s)
found=0

echo -e "📅 Daftar User Trojan yang Akan Expired (< 3 hari):"
echo "=============================================="

# Simpan hasil sementara ke file
temp_output=$(mktemp)

while IFS= read -r line; do
  user=$(echo "$line" | awk '{print $1}')
  exp=$(echo "$line" | awk '{print $2}')
  
  if [[ -z "$exp" || "$exp" == "null" ]]; then
    continue
  fi

  exp_ts=$(date -d "$exp" +%s 2>/dev/null)
  if [[ $? -ne 0 ]]; then
    continue
  fi

  remaining=$(( (exp_ts - today) / 86400 ))
  if [[ $remaining -ge 0 && $remaining -lt 3 ]]; then
    echo -e "👤 $user\n   └── Expired: $exp (dalam $remaining hari)" >> "$temp_output"
    found=1
  fi
done < <(jq -r '.inbounds[] | select(.protocol=="trojan") | .settings.clients[] | "\(.email) \(.expired)"' "$CONFIG")

# Tampilkan hasil
cat "$temp_output"
rm "$temp_output"

if [[ $found -eq 0 ]]; then
  echo "❌      Tidak ada user Trojan yang akan expired dalam 3 hari ke depan."
fi

echo "=============================================="
read -n 1 -s -r -p "↩️ Tekan tombol apa saja untuk kembali ke menu..."
echo ""

#!/bin/bash

clear
echo -e "\n=== LIST USER SSH AKTIF ===\n"

if ! command -v who &>/dev/null; then
  echo "❌ Perintah 'who' tidak ditemukan."
  exit 1
fi

who_output=$(who)

if [[ -z "$who_output" ]]; then
  echo "Tidak ada user SSH yang sedang aktif login."
else
  echo "$who_output" | awk '{print $1, $2, $3, $4, $5}'
fi

echo
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


#!/bin/bash

limit=1  # Jumlah maksimal session yang diizinkan

# Ambil list user SSH dari /etc/passwd dengan UID >=1000 (user biasa)
users=$(awk -F: '$3 >= 1000 && $3 != 65534 { print $1 }' /etc/passwd)

for user in $users; do
  count=$(ps -u $user --no-headers | wc -l)
  if [[ $count -gt $limit ]]; then
    echo "❌ $user login di $count session, kill yang lebih..."
    pkill -u $user
  fi
done


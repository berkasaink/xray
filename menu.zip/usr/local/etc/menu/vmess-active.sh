#!/bin/bash

LOG_FILE="/var/log/xray/access.log"
CONFIG_FILE="/usr/local/etc/xray/config.json"

echo "📡 IP Terakhir User VMess:"
echo "================================="

if [ ! -f "$LOG_FILE" ]; then
  echo "❌ Log Xray tidak ditemukan di: $LOG_FILE"
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

# Ambil semua email dari config.json
users=$(grep -oP '(?<="email": ")[^"]*' "$CONFIG_FILE")
found=0

for user in $users; do
  ip_last=$(grep "email: $user" "$LOG_FILE" | grep "from" | tail -n1 | awk -F 'from ' '{print $2}' | awk '{print $1}')
  if [ -n "$ip_last" ]; then
    echo "👤 $user"
    echo "   └── IP Terakhir: $ip_last"
    echo ""
    found=1
  fi
done

if [ "$found" -eq 0 ]; then
  echo "❌ Tidak ada user yang aktif saat ini."
fi

echo "================================="
read -n1 -s -r -p "Tekan tombol untuk kembali..."


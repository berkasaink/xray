#!/bin/bash
while true; do
  clear
  echo "==== Menu VMess ===="
  echo "1. Tambah Akun"
  echo "2. Perpanjang Masa Aktif"
  echo "3. Hapus Akun"
  echo "4. Ubah UUID"
  echo "5. Cek User Aktif"
  echo "6. Cek User Akan Expired"
  echo "0. Kembali"
  echo -n "Pilih: "; read vmess_opt
  case "$vmess_opt" in
    1) bash /usr/local/etc/menu/vmess-add.sh ;;
    2) bash /usr/local/etc/menu/vmess-renew.sh ;;
    3) bash /usr/local/etc/menu/vmess-delete.sh ;;
    4) bash /usr/local/etc/menu/vmess-uuid.sh ;;
    5) bash /usr/local/etc/menu/vmess-active.sh ;;
    6) bash /usr/local/etc/menu/vmess-expiring.sh ;;
    0) break ;;   # <-- Perbaikan: pastikan break berada di dalam blok
    *) echo "Pilihan tidak valid!" ; sleep 1 ;;
  esac
done


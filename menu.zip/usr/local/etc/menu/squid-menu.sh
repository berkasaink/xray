#!/bin/bash

MENU_DIR="/usr/local/etc/menu"

while true; do
  clear
  echo "===== Menu Manajemen Squid Proxy ====="
  echo "1. Tambah User"
  echo "2. Perpanjang User"
  echo "3. Hapus User"
  echo "4. Ganti Password"
  echo "5. List User"
  echo "6. Auto Kill (>2 IP)"
  echo "0. Kembali ke Menu Utama"
  echo "======================================"
  read -p "Pilih [0-6]: " opt
  case $opt in
    1) bash "$MENU_DIR/squid-add.sh" ;;
    2) bash "$MENU_DIR/squid-renew.sh" ;;
    3) bash "$MENU_DIR/squid-del.sh" ;;
    4) bash "$MENU_DIR/squid-passwd.sh" ;;
    5) bash "$MENU_DIR/squid-list.sh" ;;
    6) bash "$MENU_DIR/squid-kill.sh" ;;
    0) break ;;
    *) echo "❌ Pilihan tidak valid!" ; sleep 1 ;;
  esac
done


#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
today=$(date +%s)
limit_days=3  # Hanya tampilkan yang < 3 hari

echo "⏳ User VMess Expiring Kurang dari $limit_days Hari:"
echo "==========================================================="

if [ ! -f "$CONFIG_FILE" ]; then
  echo "❌ config.json tidak ditemukan di: $CONFIG_FILE"
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

# Ambil semua user dan tanggal expired dari config.json
users=$(jq -r '.inbounds[]?.settings.clients[]? | select(.email and .expireDate) | "\(.email) \(.expireDate)"' "$CONFIG_FILE")
found=0

while read -r line; do
  user=$(echo "$line" | awk '{print $1}')
  date_str=$(echo "$line" | awk '{print $2}')
  exp_timestamp=$(date -d "$date_str" +%s 2>/dev/null)

  if [ $? -ne 0 ]; then
    echo "⚠️ Format tanggal tidak valid: $user ($date_str)"
    continue
  fi

  remaining_days=$(( (exp_timestamp - today) / 86400 ))

  if [ "$remaining_days" -ge 0 ] && [ "$remaining_days" -lt "$limit_days" ]; then
    echo "👤 $user akan expired dalam $remaining_days hari (📅 $date_str)"
    found=1
  fi
done <<< "$users"

if [ "$found" -eq 0 ]; then
  echo "✅ Tidak ada user yang expired dalam < $limit_days hari ke depan."
fi

echo "==========================================================="
read -n1 -s -r -p "Tekan tombol untuk kembali..."


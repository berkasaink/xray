#!/bin/bash

clear
echo -e "\n=== LIST USER SSH YANG AKAN EXPIRED (<=7 Hari) ===\n"
printf "%-20s %-15s\n" "Username" "Expire Dalam (Hari)"
echo "────────────────────────────────────────────"

today=$(date +%s)

# Ambil semua user dengan UID >= 1000 (user biasa)
for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
    expire_raw=$(chage -l $user | grep "Account expires" | cut -d: -f2 | sed 's/^\s*//g')

    if [[ "$expire_raw" != "never" ]]; then
        expire_date=$(date -d "$expire_raw" +%Y-%m-%d 2>/dev/null)
        expire_seconds=$(date -d "$expire_date" +%s 2>/dev/null)
        remaining_days=$(( (expire_seconds - today) / 86400 ))

        if [[ $remaining_days -ge 0 && $remaining_days -le 7 ]]; then
            printf "%-20s %-15s\n" "$user" "$remaining_days"
        fi
    fi
done

echo
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


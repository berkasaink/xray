#!/bin/bash
config_file="/usr/local/etc/xray/config.json"
domain=$(cat /etc/xray/domain)
port_ws=80
port_wss=443
path_ws="/vmess"
clear
echo -e "=== Tambah Akun VMess ==="
read -p "Masukkan username: " username
# Cek apakah username sudah ada
if grep -q "\"email\": \"$username\"" "$config_file"; then
    echo "❌  Username '$username' sudah terdaftar."
    read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
    exit 1
fi
read -p "Masukkan masa aktif (hari): " masa_aktif
uuid=$(uuidgen)
expire_date=$(date -d "$masa_aktif days" +%Y-%m-%d)
# Sisipkan user ke bagian clients inbound VMess
tmp=$(mktemp)
jq '(.inbounds[] | select(.tag == "vmess") | .settings.clients) +=
    [{"id": "'$uuid'", "alterId": 0, "email": "'$username'", "expireDate": "'$expire_date'"}]' \
    "$config_file" > "$tmp" && mv "$tmp" "$config_file"
# Restart Xray
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart xray
# Tampilkan info akun
vmess_json=$(cat <<EOF
{
  "v": "2",
  "ps": "$username",
  "add": "$domain",
  "port": "$port_ws",
  "id": "$uuid",
  "aid": "0",
  "net": "ws",
  "type": "none",
  "host": "$domain",
  "path": "$path_ws",
  "tls": ""
}
EOF
)
link_ws="vmess://$(echo "$vmess_json" | base64 -w 0)"
vmess_json_tls=$(echo "$vmess_json" | jq '.port = "'$port_wss'" | .tls = "tls"')
link_wss="vmess://$(echo "$vmess_json_tls" | base64 -w 0)"
clear
echo "=== Akun VMess berhasil ditambahkan ==="
echo "Username : $username"
echo "Domain   : $domain"
echo "UUID     : $uuid"
echo "Expired  : $expire_date"
echo "Port WS  : $port_ws"
echo "Port WSS : $port_wss"
echo "Link WS  : $link_ws"
echo "Link WSS : $link_wss"
echo "====================================="
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


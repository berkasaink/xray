#!/bin/bash
# Auto remove expired SSH, VMess, and Trojan users
CONFIG_FILE="/usr/local/etc/xray/config.json"
TODAY=$(date +%s)
TMP_FILE="/tmp/tmp_config.json"
> "$TMP_FILE"

echo -e "📅 Daftar User Xray (VMess & Trojan) yang Expired:"
echo "==============================================="

# Fungsi hapus user Xray (vmess & trojan)
jq '.inbounds' "$CONFIG_FILE" | jq -c '.[]' | while read -r inbound; do
    proto=$(echo "$inbound" | jq -r '.protocol')
    tag=$(echo "$inbound" | jq -r '.tag')
    clients=$(echo "$inbound" | jq '.settings.clients')

    new_clients="[]"
    for row in $(echo "$clients" | jq -c '.[]'); do
        email=$(echo "$row" | jq -r '.email')
        expire=$(echo "$row" | jq -r '.expireDate // .expired // empty')
        if [[ -z "$expire" ]]; then
            new_clients=$(echo "$new_clients" | jq --argjson row "$row" '. += [$row]')
            continue
        fi

        exp_sec=$(date -d "$expire" +%s 2>/dev/null)
        if [[ -z "$exp_sec" || "$exp_sec" -ge "$TODAY" ]]; then
            new_clients=$(echo "$new_clients" | jq --argjson row "$row" '. += [$row]')
        else
            echo "❌   User $email expired ($expire), removed."
        fi
    done

    inbound=$(echo "$inbound" | jq --argjson clients "$new_clients" '.settings.clients = $clients')
    echo "$inbound" >> "$TMP_FILE"
done

# Update config.json
jq --argjson inbounds "$(jq -s '.' "$TMP_FILE")" \
   '.inbounds = $inbounds' "$CONFIG_FILE" > "$CONFIG_FILE.new" && mv "$CONFIG_FILE.new" "$CONFIG_FILE"
rm -f "$TMP_FILE"

# Restart Xray
systemctl restart xray > /dev/null 2>&1

# SSH expired user
echo -e "\n📅 Daftar User SSH yang Expired:"
echo "==============================================="
while IFS= read -r user; do
    exp_date=$(chage -l "$user" 2>/dev/null | grep "Account expires" | awk -F": " '{print $2}')
    [[ "$exp_date" == "never" || -z "$exp_date" ]] && continue
    exp_sec=$(date -d "$exp_date" +%s 2>/dev/null)
    if [[ "$exp_sec" -lt "$TODAY" ]]; then
        userdel -rf "$user" && echo "❌   SSH User $user expired ($exp_date), removed."
    fi
done < <(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd)

echo "✅   Auto expired check selesai."


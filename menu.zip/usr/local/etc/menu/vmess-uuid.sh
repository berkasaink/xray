#!/bin/bash

config_file="/usr/local/etc/xray/config.json"

clear
echo "=== Ubah UUID Akun VMess ==="

# Ambil list user VMess
users=$(jq -r '.inbounds[] | select(.tag=="vmess") | .settings.clients[]?.email' "$config_file")
if [[ -z "$users" ]]; then
  echo "❌ Tidak ada akun VMess ditemukan."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit
fi

# Tampilkan daftar user
i=1
declare -A usermap
echo "=== Daftar Akun ==="
while read -r user; do
  echo " $i) $user"
  usermap[$i]="$user"
  ((i++))
done <<< "$users"

# Input pilihan user
read -p "Pilih nomor user untuk diubah UUID: " pilihan
username="${usermap[$pilihan]}"

# Validasi input
if [[ -z "$username" ]]; then
  echo "❌ Pilihan tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit
fi

# Input UUID manual
read -p "Masukkan UUID baru: " new_uuid
if [[ -z "$new_uuid" || ! "$new_uuid" =~ ^[a-fA-F0-9\-]{36}$ ]]; then
  echo "❌ Format UUID tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit
fi

# Update UUID di config.json
tmp=$(mktemp)
jq '(.inbounds[] | select(.tag=="vmess") | .settings.clients[] | select(.email=="'"$username"'")).id = "'"$new_uuid"'"' "$config_file" > "$tmp" && mv "$tmp" "$config_file"

# Restart Xray
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart xray

# Tampilkan hasil
echo ""
echo "✅ UUID berhasil diubah!"
echo "Username : $username"
echo "UUID Baru: $new_uuid"
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


#!/bin/bash

LOG="/var/log/xray/access.log"
LIMIT=1
TMP="/tmp/xray-multilogin.tmp"
> "$TMP"

# Ambil semua log yang mengandung `email:`
grep "email:" "$LOG" | while read line; do
    email=$(echo "$line" | grep -oP "email:\s*\K\S+")
    ip=$(echo "$line" | grep -oP "from\s+(tcp:)?\K[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+")
    [[ -n "$email" && -n "$ip" ]] && echo "$email $ip" >> "$TMP"
done

# Hitung jumlah IP unik per user
cut -d' ' -f1 "$TMP" | sort | uniq | while read user; do
    count=$(grep "^$user " "$TMP" | cut -d' ' -f2 | sort | uniq | wc -l)
    if [[ "$count" -gt "$LIMIT" ]]; then
        echo "❌  $user login lebih dari $LIMIT IP:"
        grep "^$user " "$TMP" | cut -d' ' -f2 | sort | uniq | while read ip; do
            echo "   🔒 Blokir IP: $ip"
            iptables -I INPUT -s "$ip" -j DROP
        done
    fi
done


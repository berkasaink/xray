#!/bin/bash

cron_file="/etc/cron.d/auto_reboot"

menu() {
  clear
  echo -e "🔁 Menu Auto Reboot VPS"
  echo "==========================="
  echo "1. Aktifkan Auto Reboot Harian"
  echo "2. Matikan Auto Reboot"
  echo "3. Cek Status Auto Reboot"
  echo "0. Kembali ke Menu Utama"
  echo "==========================="
  read -p "Pilih [0-3]: " opt
  case $opt in
    1)
      read -p "Masukkan jam reboot (format 24 jam, contoh 03): " jam
      [[ ! "$jam" =~ ^([01]?[0-9]|2[0-3])$ ]] && echo "⛔ Format jam tidak valid!" && sleep 2 && menu
      echo "0 $jam * * * root /sbin/reboot" > "$cron_file"
      chmod 644 "$cron_file"
      echo "✅ Auto reboot diatur tiap hari jam $jam:00"
      ;;
    2)
      rm -f "$cron_file"
      echo "❌ Auto reboot dinonaktifkan"
      ;;
    3)
      if [[ -f "$cron_file" ]]; then
        echo "📆 Jadwal Auto Reboot Saat Ini:"
        cat "$cron_file"
      else
        echo "❌ Auto Reboot tidak aktif."
      fi
      ;;
    0)
      /usr/local/bin/menu
      exit
      ;;
    *)
      echo "⛔ Pilihan tidak valid"
      ;;
  esac
  echo ""
  read -n 1 -s -r -p "↩️ Tekan tombol apa saja untuk kembali..."
  menu
}

menu


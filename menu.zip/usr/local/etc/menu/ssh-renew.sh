#!/bin/bash

clear
echo -e "\n=== PERPANJANG AKUN SSH ===\n"

# Dapatkan daftar user dengan shell /bin/bash (user aktif)
users=$(awk -F: '$7 ~ /\/bin\/bash/ {print $1}' /etc/passwd)

if [[ -z "$users" ]]; then
  echo "❌ Tidak ada akun SSH untuk diperpanjang."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# Tampilkan user dengan urutan angka
i=1
declare -A user_map
echo "Daftar Akun SSH:"
echo "──────────────────────"
for user in $users; do
  exp=$(chage -l "$user" | grep "Account expires" | awk -F": " '{print $2}')
  echo "$i) $user (Expired: $exp)"
  user_map[$i]=$user
  ((i++))
done

echo
read -rp "Pilih nomor user: " nomor
selected_user="${user_map[$nomor]}"

if [[ -z "$selected_user" ]]; then
  echo "❌ Nomor tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

read -rp "Perpanjang berapa hari?: " tambah_hari
if ! [[ "$tambah_hari" =~ ^[0-9]+$ ]]; then
  echo "❌ Input hari tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# Hitung tanggal baru
tgl_exp_baru=$(date -d "$tambah_hari days" +%Y-%m-%d)
chage -E "$tgl_exp_baru" "$selected_user"

echo -e "\n✅ Akun '$selected_user' berhasil diperpanjang!"
echo "Masa aktif sampai: $tgl_exp_baru"
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


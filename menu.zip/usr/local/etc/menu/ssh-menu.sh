#!/bin/bash

while true; do
  clear
  echo "==== Menu SSH ===="
  echo "1. Tambah Akun"
  echo "2. Perpanjang Akun"
  echo "3. Hapus Akun"
  echo "4. List User Akan Expired"
  echo "5. List Akun Aktif"
  echo "0. Kembali"
  echo -n "Pilih: "; read ssh_opt

  case "$ssh_opt" in
    1) bash /usr/local/etc/menu/ssh-add.sh ;;
    2) bash /usr/local/etc/menu/ssh-renew.sh ;;
    3) bash /usr/local/etc/menu/ssh-delete.sh ;;
    4) bash /usr/local/etc/menu/ssh-expiring.sh ;;
    5) bash /usr/local/etc/menu/ssh-active.sh ;;
    0) break ;;
    *) echo "Pilihan tidak valid!" ; sleep 1 ;;
  esac
done


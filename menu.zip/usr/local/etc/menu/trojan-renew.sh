#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
XRAY_SERVICE="xray"

# Ambil daftar user trojan
user_list=($(jq -r '.inbounds[] | select(.protocol=="trojan") | .settings.clients[].email' "$CONFIG_FILE"))

# Cek jika tidak ada user
if [ ${#user_list[@]} -eq 0 ]; then
  echo "❌ Tidak ada user Trojan yang terdaftar."
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

# Tampilkan daftar user
echo "📄 Daftar User Trojan:"
echo "────────────────────────────"
for i in "${!user_list[@]}"; do
  echo "$((i+1)). ${user_list[$i]}"
done
echo "────────────────────────────"

# Input pilihan user
read -p "🔢 Pilih nomor user: " pilih
index=$((pilih-1))
user="${user_list[$index]}"

# Cek tanggal expired lama
current_exp=$(jq -r --arg user "$user" '
  .inbounds[] 
  | select(.protocol == "trojan") 
  | .settings.clients[] 
  | select(.email == $user) 
  | .expireDate' "$CONFIG_FILE")

# Validasi user dan tanggal
if [[ -z "$current_exp" || "$current_exp" == "null" ]]; then
  echo "❌ User tidak ditemukan atau tidak memiliki tanggal expired."
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

echo "📅 Tanggal expired saat ini: $current_exp"
read -p "🆕 Tambah berapa hari: " tambahan

# Hitung tanggal baru
new_exp=$(date -d "$current_exp +$tambahan days" +"%Y-%m-%d")

# Update config.json
tmpfile=$(mktemp)
jq --arg user "$user" --arg new_exp "$new_exp" '
  (.inbounds[] 
   | select(.protocol == "trojan") 
   | .settings.clients[] 
   | select(.email == $user)).expireDate = $new_exp' \
  "$CONFIG_FILE" > "$tmpfile" && mv "$tmpfile" "$CONFIG_FILE"

# Restart service
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart "$XRAY_SERVICE"

echo ""
echo "✅ Masa aktif '$user' berhasil diperpanjang."
echo "📅 Tanggal baru: $new_exp"
read -n1 -s -r -p "Tekan tombol apa saja untuk kembali ke menu..."


#!/bin/bash

PASSWD_FILE="/etc/squid/passwd"
USER_DB="/etc/squid/user-db.txt"
DOMAIN_FILE="/etc/xray/domain"

echo "=== Tambah User Proxy Squid ==="
read -p "Masukkan username         : " user
read -p "Masukkan password         : " password
read -p "Masa aktif (dalam hari)   : " days

# Validasi input kosong
if [[ -z "$user" || -z "$password" || -z "$days" ]]; then
  echo "❌ Username, password, dan masa aktif wajib diisi!"
  echo ""
  read -n 1 -s -r -p "Tekan tombol apapun untuk kembali ke menu..."
  exit 1
fi

# Cek jika user sudah ada
if grep -q "^$user:" "$PASSWD_FILE"; then
  echo "❌ Username '$user' sudah terdaftar!"
  echo ""
  read -n 1 -s -r -p "Tekan tombol apapun untuk kembali ke menu..."
  exit 1
fi

# Tambahkan user
htpasswd -b "$PASSWD_FILE" "$user" "$password"

# Catat masa berlaku
exp_date=$(date -d "+$days days" +%Y-%m-%d)
echo "$user $exp_date" >> "$USER_DB"

# Reload squid
systemctl reload squid > /dev/null 2>&1

# Ambil domain atau fallback ke IP
if [[ -f "$DOMAIN_FILE" ]]; then
  domain=$(cat "$DOMAIN_FILE")
else
  domain=$(hostname -I | awk '{print $1}')
fi

# Tampilkan hasil
echo ""
echo "✅ User berhasil ditambahkan!"
echo "-----------------------------"
echo "🔐 Username : $user"
echo "🔑 Password : $password"
echo "📅 Expired  : $exp_date"
echo "🌐 Proxy    : http://$user:$password@$domain:2025"
echo ""
read -n 1 -s -r -p "Tekan tombol apapun untuk kembali ke menu..."


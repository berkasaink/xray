#!/bin/bash

# === Konfigurasi ===
domain_file="/etc/xray/domain"
[[ -s "$domain_file" ]] && domain=$(cat "$domain_file") || {
  read -rp "Masukkan domain: " domain
  echo "$domain" > "$domain_file"
}

ssh_ws_port=80
ssh_ssl_port=443
ssh_dropbear_port=110
ssh_port=22

# === Input Username ===
read -rp "Username: " username
if id "$username" &>/dev/null; then
  echo
  echo "❌ USER '$username' SUDAH TERDAFTAR!"
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# === Input Password & Masa Aktif ===
read -rp "Password: " password
read -rp "Masa aktif (hari): " masa_aktif

# Validasi masa aktif
if ! [[ "$masa_aktif" =~ ^[0-9]+$ ]]; then
  echo
  echo "❌ Masa aktif harus berupa angka!"
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# === Tambah User ===
exp_date=$(date -d "$masa_aktif days" +%Y-%m-%d)
useradd -e "$exp_date" -s /bin/bash -M "$username"
echo "${username}:${password}" | chpasswd
usermod -s /bin/bash "$username"

# === Konfirmasi Berhasil ===
clear
echo -e "\n✅ SSH AKUN BERHASIL DIBUAT!\n"
echo "Informasi Akun:"
echo "────────────────────────────────────"
echo "Domain        : $domain"
echo "Username      : $username"
echo "Password      : $password"
echo "Expired       : $exp_date"
echo "Port OpenSSH  : $ssh_port"
echo "Port Dropbear : $ssh_dropbear_port"
echo "Port WS       : $ssh_ws_port"
echo "Port WSS      : $ssh_ssl_port"
echo
echo "Payload WebSocket:"
echo "GET / HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]"
echo "────────────────────────────────────"
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
DOMAIN_FILE="/etc/xray/domain"
XRAY_SERVICE="xray"

# Ambil domain dari file
if [ ! -f "$DOMAIN_FILE" ]; then
  echo "❌ File domain tidak ditemukan: $DOMAIN_FILE"
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi
domain=$(cat "$DOMAIN_FILE")

# Input username
read -p "🆔 Masukkan nama user: " user
if grep -q "\"email\": \"$user\"" "$CONFIG_FILE"; then
  echo "❌ User sudah ada di config.json!"
  read -n1 -s -r -p "Tekan tombol untuk kembali..."
  exit 1
fi

# Input masa aktif
read -p "📅 Masa aktif (dalam hari): " masa_aktif
exp_date=$(date -d "+$masa_aktif days" +"%Y-%m-%d")

# Generate UUID/password
uuid=$(cat /proc/sys/kernel/random/uuid)

# Tambahkan user ke config.json
tmpfile=$(mktemp)
jq --arg user "$user" \
   --arg pass "$uuid" \
   --arg exp "$exp_date" \
   '(.inbounds[] | select(.protocol == "trojan") | .settings.clients) += [{
     "password": $pass,
     "email": $user,
     "expireDate": $exp
   }]' "$CONFIG_FILE" > "$tmpfile" && mv "$tmpfile" "$CONFIG_FILE"

# Restart Xray
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
systemctl restart "$XRAY_SERVICE"

# Tampilkan informasi akun
echo ""
echo "✅ Akun Trojan berhasil ditambahkan!"
echo "────────────────────────────"
echo "🌐 Domain   : $domain"
echo "👤 Username : $user"
echo "🔑 Password : $uuid"
echo "📅 Expired  : $exp_date"
echo "📶 Port WS  : 80"
echo "🔒 Port WSS : 443"
echo "────────────────────────────"
echo "🔗 Link Trojan-Go:"
echo "trojan-go://$uuid@$domain:443?type=ws&path=%2Ftrojan#$user"
echo "────────────────────────────"
read -n1 -s -r -p "Tekan tombol apa saja untuk kembali ke menu..."


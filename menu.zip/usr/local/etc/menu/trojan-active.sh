#!/bin/bash

log_file="/var/log/xray/access.log"
config_file="/usr/local/etc/xray/config.json"

# Ambil daftar user Trojan dari config
mapfile -t user_list < <(jq -r '.inbounds[] | select(.protocol=="trojan") | .settings.clients[]?.email' "$config_file")

declare -A user_last_ip
declare -A user_last_time

# Fungsi untuk konversi waktu log ke detik unix timestamp
log_time_to_unix() {
    # $1 contoh: 2025/06/17 20:16:08.589630
    date -d "${1%.*}" +%s 2>/dev/null
}

now=$(date +%s)

while IFS= read -r line; do
    # Parse waktu di awal log (format YYYY/MM/DD HH:MM:SS.ssssss)
    log_time=$(echo "$line" | grep -oP '^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}\.\d+')
    log_unix=$(log_time_to_unix "$log_time")

    # Kalau parsing waktu gagal, skip
    if [[ -z "$log_unix" ]]; then
        continue
    fi

    diff=$(( now - log_unix ))

    # Cek waktu aktivitas kurang dari 60 detik
    if (( diff >= 0 && diff <= 60 )); then
        # Ambil email user
        user=$(echo "$line" | grep -oP 'email: \K\S+')
        # Pastikan user valid dan termasuk dalam daftar Trojan
        if [[ " ${user_list[*]} " == *" $user "* ]]; then
            # Ambil IP dari "from xxx.xxx.xxx.xxx" (abaikan tcp: prefix)
            ip=$(echo "$line" | grep -oP 'from (tcp:)?\K[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+')
            if [[ -n "$ip" ]]; then
                # Simpan IP terakhir dan waktu terakhir (overwrite)
                user_last_ip["$user"]=$ip
                user_last_time["$user"]=$log_unix
            fi
        fi
    fi
done < "$log_file"

clear
echo "📡 User Trojan yang sedang aktif (IP terakhir, aktif < 1 menit):"
echo "================================="

if [ ${#user_last_ip[@]} -eq 0 ]; then
    echo "❌  Tidak ada user yang aktif dalam 1 menit terakhir."
else
    for user in "${!user_last_ip[@]}"; do
        echo "👤 $user"
        echo "   └── IP: ${user_last_ip[$user]}"
    done
fi

echo "================================="
echo ""
read -n 1 -s -r -p "↩️ Tekan tombol apa saja untuk kembali ke menu..."


#!/bin/bash

CONFIG_FILE="/usr/local/etc/xray/config.json"
TODAY=$(date +%s)
EXPIRED_USERS=()

echo "📅 Daftar User Xray (VMess & Trojan) yang Expired:"
echo "==============================================="

# Loop semua inbound
jq -c '.inbounds[]' "$CONFIG_FILE" | while read -r inbound; do
  PROTOCOL=$(jq -r '.protocol' <<< "$inbound")
  TAG=$(jq -r '.tag' <<< "$inbound")
  echo "" > /dev/null  # Dummy supaya tetap bisa pakai loop
  
  jq -c '.settings.clients[]?' <<< "$inbound" | while read -r client; do
    EMAIL=$(jq -r '.email' <<< "$client")
    EXPIRE=$(jq -r '.expireDate // .expired' <<< "$client")
    
    # Lewati jika tidak ada tanggal
    [[ "$EXPIRE" == "null" || -z "$EXPIRE" ]] && continue

    EXPIRE_DATE=$(date -d "$EXPIRE" +%s 2>/dev/null)
    [[ -z "$EXPIRE_DATE" ]] && continue

    if (( TODAY >= EXPIRE_DATE )); then
      EXPIRED_USERS+=("$EMAIL")
      echo "❌  User $EMAIL expired ($EXPIRE), removed."
    fi
  done
done

# Hapus user expired
if (( ${#EXPIRED_USERS[@]} > 0 )); then
  for user in "${EXPIRED_USERS[@]}"; do
    jq '(.inbounds[].settings.clients) |= map(select(.email != "'$user'"))' "$CONFIG_FILE" > /tmp/config.tmp && mv /tmp/config.tmp "$CONFIG_FILE"
  done
chown -R nobody:nogroup /usr/local/etc/xray
chmod -R 755 /usr/local/etc/xray
  systemctl restart xray
else
  echo "✅   Tidak ada user yang expired."
fi


#!/bin/bash

clear
echo -e "\n=== HAPUS AKUN SSH ===\n"

# Ambil user SSH aktif (yang shell-nya /bin/bash)
users=$(awk -F: '$7 ~ /\/bin\/bash/ {print $1}' /etc/passwd)

if [[ -z "$users" ]]; then
  echo "❌ Tidak ada akun SSH yang tersedia."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# Tampilkan user dalam bentuk daftar terurut
i=1
declare -A user_map
echo "Daftar Akun SSH:"
echo "──────────────────────"
for user in $users; do
  echo "$i) $user"
  user_map[$i]=$user
  ((i++))
done

echo
read -rp "Pilih nomor user yang akan dihapus: " nomor
selected_user="${user_map[$nomor]}"

if [[ -z "$selected_user" ]]; then
  echo "❌ Nomor tidak valid."
  read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."
  exit 1
fi

# Hapus user tanpa menampilkan pesan error jika direktori atau mail tidak ada
userdel -f "$selected_user" &>/dev/null

echo -e "\n✅ User '$selected_user' berhasil dihapus."
read -n 1 -s -r -p "Tekan sembarang tombol untuk kembali..."


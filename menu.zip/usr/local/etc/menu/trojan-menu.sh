#!/bin/bash

while true; do
  clear
  echo "==== Menu Trojan ===="
  echo "1. Tambah Akun"
  echo "2. Perpanjang Masa Aktif"
  echo "3. Hapus Akun"
  echo "4. Ubah Password"
  echo "5. Cek User Aktif"
  echo "6. Cek User Akan Expired"
  echo "0. Kembali"
  echo -n "Pilih: "; read trojan_opt

  case "$trojan_opt" in
    1) bash /usr/local/etc/menu/trojan-add.sh ;;
    2) bash /usr/local/etc/menu/trojan-renew.sh ;;
    3) bash /usr/local/etc/menu/trojan-delete.sh ;;
    4) bash /usr/local/etc/menu/trojan-passwd.sh ;;
    5) bash /usr/local/etc/menu/trojan-active.sh ;;
    6) bash /usr/local/etc/menu/trojan-expiring.sh ;;
    0) break ;;
    *) echo "Pilihan tidak valid!" ; sleep 1 ;;
  esac
done

